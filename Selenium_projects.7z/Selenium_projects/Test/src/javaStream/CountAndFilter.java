package javaStream;

import java.util.ArrayList;
import java.util.stream.Stream;

public class CountAndFilter {

	public static void main(String[] args) {
		
		ArrayList<String> name = new ArrayList<String>();
		name.add("Suresh");
		name.add("Karthikka");
		name.add("Deepa");
		name.add("Saravanesh");
		name.add("Babu");
		
		int count = 0;
		for (int i = 0; i < name.size(); i++) {
			String actual = name.get(i);
			if(actual.startsWith("S"))
				count++;
		}
		System.out.println("count :"+count);
		
		Long c = name.stream().filter(s->s.startsWith("K")).count();
		System.out.println("Stream count : "+c);
		
		// print all the names
		name.stream().forEach(s->System.out.println(s));
		
		// print names whose length is greater than 5
		System.out.println("\nlength greater than 5");		
		name.stream().filter(s->s.length()>5).forEach(s->System.out.println(s));
		
		// print only first result whose length is greater than 5
		System.out.println("\nPrint only first result whose length greater than 5");	
		name.stream().filter(s->s.length()>5).limit(1).forEach(s->System.out.println(s));
		
		// print names ends with 'h' and print in upper case
		
		System.out.println("\nprint names ends with 'h' and print in upper case");		
		Stream.of("Suresh","Deepa","Karthikka","Saravanesh","Babu").filter(s->s.endsWith("h")).map(s->s.toUpperCase())
		.forEach(s->System.out.println(s));
		
		// print names starts with 's' and print in upper case with sorted order
		System.out.println("\nprint names starts with 's' and print in upper case with sorted order");	
		Stream.of("Suresh","Deepa","Karthikka","Saravanesh","Babu").filter(s->s.startsWith("S")).sorted().map(s->s.toUpperCase())
		.forEach(s->System.out.println(s));
		

	}

}
