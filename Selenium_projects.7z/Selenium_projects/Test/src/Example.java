import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class Example {

	public static void main(String[] args) throws ParseException {
	//	String os = System.getProperty("os.name").toLowerCase();
	//	System.out.println(os);
		
//		String sdate1 = "Aug 25 2020 - 5:30";
//		SimpleDateFormat formatter1=new SimpleDateFormat("MMM dd yyyy - HH:MM");  
//		Date date1=formatter1.parse(sdate1); 
//		System.out.println(date1);
	
		  DateTimeFormatter formatter_1 = DateTimeFormatter.ofPattern("d/MM/yyyy");
		  String str_date_1 = "24/09/2019";

		  LocalDate local_date_1 = LocalDate.parse(str_date_1, formatter_1);
 
		  System.out.println(local_date_1);

	}

}
