

public class stringExample {
	
	public static String extractDigits(String src) {
	    StringBuilder builder = new StringBuilder();
	    for (int i = 0; i < src.length(); i++) {
	        char c = src.charAt(i);
	        if (Character.isDigit(c)) {
	            builder.append(c);
	        }
	    }
	    return builder.toString();
	}

	public static void main(String[] args) {
	
		
		String S1 = "Nisum";
		String S2 = new String(S1);
		String S3 ="Nisum";
		System.out.println(S1.equals(S2)); // content comparison
		System.out.println(S1==S2);  // address comparison
		System.out.println(S3==S1);  // address comparison
		
		   String s="asdp[]90@12#%";        
	        String s1=s.replaceAll("[^0-9]+", ""); //*replacing all the value of string except digit by using "[^0-9]+" regex.*
	        
	       System.out.println(s1);  
	       
           String str = "Suresh1234Babu";
	       String sb =   extractDigits(str);

	}
	

}
