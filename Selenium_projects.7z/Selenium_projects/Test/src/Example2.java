
public class Example2 {

	public static void main(String[] args) {
		String dateval = "Aug 24 2020 - 07:30 AM";
		
		String test = "arguments[0].setAttribute('value','"+dateval+"');";
		System.out.println(test);

	}

}
