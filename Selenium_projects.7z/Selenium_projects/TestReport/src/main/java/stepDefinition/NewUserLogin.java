package stepDefinition;

import java.util.List;

import org.openqa.selenium.support.PageFactory;

import appUtils.BaseClass;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

public class NewUserLogin extends BaseClass{
	String user,usertxt;
	
	@Then("^user should able to login into home page of curator application and username user display in the homepage$")
	public void user_should_able_to_login_into_home_page_of_curator_application_and_username_user_display_in_the_homepage(DataTable arg1) throws Throwable {
		
		List<List<String>> usrdata = arg1.raw();
		user = usrdata.get(1).get(0);
		
		PageFactory.initElements(driver, pageObjects.Login.class);
		usertxt = pageObjects.Login.username.getText();
//		System.out.println("user login name : " +usertxt);
		
		if (usertxt.contains(user))
			System.out.println("logged into as a "+usertxt+ " user" );
		else
			System.out.println(user + " is not logged in");
	
	}

}
