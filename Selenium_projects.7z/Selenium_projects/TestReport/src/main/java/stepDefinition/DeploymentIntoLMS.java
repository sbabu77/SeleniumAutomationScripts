package stepDefinition;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.support.PageFactory;

import appUtils.BaseClass;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import stepDefinition.NewCourseConnector;

public class DeploymentIntoLMS extends BaseClass{
	
	String crsName,status,lastdepdate;
	
	@When("^user enter course name in search text box and search the respective course$")
	public void user_enter_course_name_in_search_text_box_and_search_the_respective_course(DataTable coursetbl) throws Throwable {
	
		PageFactory.initElements(driver, pageObjects.CourseDeployments.class);
		List<List<String>> deployTable = coursetbl.raw();
		crsName = deployTable.get(1).get(0);
		pageObjects.CourseDeployments.CourseSearchBox.sendKeys(crsName);
		
	}

	@When("^click the modify button and select Deploy option$")
	public void click_the_modify_button_and_select_Deploy_option() throws Throwable {
		pageObjects.CourseDeployments.ModifyBtn.click();
		pageObjects.CourseDeployments.DeployBtn.click();
		
		
		
	}

	@When("^click the Deploy Now option and click OK option in the confirmation window$")
	public void click_the_Deploy_Now_option_and_click_OK_option_in_the_confirmation_window() throws Throwable {
		pageObjects.CourseDeployments.DeployNowBtn.click();
		wait(pageObjects.CourseDeployments.OKConfirmationBtn);
		pageObjects.CourseDeployments.OKConfirmationBtn.click();
	//	driver.navigate().refresh();
	}

	@Then("^deployment happen successfully and current system is displayed in last deployment column and status is updated as Current$")
	public void deployment_happen_successfully_and_current_system_is_displayed_in_last_deployment_column_and_status_is_updated_as_Current() throws Throwable {
	
		PageFactory.initElements(driver, pageObjects.Deploy.class);
		wait(pageObjects.Deploy.Deploylink);
		pageObjects.Deploy.Deploylink.click();
		PageFactory.initElements(driver, pageObjects.CourseDeployments.class);
		
		DateFormat dateFormat = new SimpleDateFormat("MMMM dd, YYYY");
		Date date = new Date();
		String ldate= dateFormat.format(date);
		
		
		lastdepdate = pageObjects.CourseDeployments.LastDeployedDate.getText();
		status=pageObjects.CourseDeployments.StatusBtn.getText();
		System.out.println("Last Deployment Date: " +lastdepdate);
		System.out.println("Deployment Status : " +status);

		if (status.contains("Current")) {
			if (lastdepdate.equalsIgnoreCase(ldate))
			{
				System.out.println("Course deployed successfully into LMS");
			}
		}

	}

}
