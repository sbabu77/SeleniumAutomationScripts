package stepDefinition;


import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;

import appUtils.BaseClass;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
//import junit.framework.Assert;

public class NewAnnouncement extends BaseClass{
	
	String title = null;
	String org = null;
	String begindate = null;
	String enddate = null;
	String details = null;
	
	@Given("^user navigate to Announcement screen$")
	public void user_navigate_to_Announcement_screen() throws Throwable {
		PageFactory.initElements(driver, pageObjects.Communication_Announcement.class);
		pageObjects.Communication_Announcement.homeiconbtn.click();
		wait(pageObjects.Communication_Announcement.Communicationlink);
		pageObjects.Communication_Announcement.Communicationlink.click();
		pageObjects.Communication_Announcement.Announcementlink.click();
		
		
	}
	

	@When("^user click the New Announcement button$")
	public void user_click_the_New_Announcement_button() throws Throwable {
		pageObjects.Communication_Announcement.NewAnnouncementBtn.click();}

	@When("^enters AnnouncementTitle, Organization, AnnouncementBeginDate, AnnouncementEndDate and AnnouncementDetails$")
	public void enters_AnnouncementTitle_Organization_AnnouncementBeginDate_AnnouncementEndDate_and_AnnouncementDetails(DataTable Annountbl) throws Throwable {
	
		List<List<String>> annodata = Annountbl.raw();
		title = annodata.get(1).get(0);
		org = annodata.get(1).get(1);
		begindate = annodata.get(1).get(2);
		enddate =annodata.get(1).get(3);
		details = annodata.get(1).get(4);
		
		pageObjects.Communication_Announcement.Announcement_title.sendKeys(title);
		pageObjects.Communication_Announcement.OrganizationDropDown.sendKeys(org);
		pageObjects.Communication_Announcement.Announcement_begin_date.clear();
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("document.getElementById('anouncement_begin_date').value='"+begindate+"'");
		js.executeScript("document.getElementById('anouncement_end_date').value='"+enddate+"'");
		
//		js.executeScript("document.getElementById('anouncement_begin_date').value='Aug 24 2020 - 07:30 AM'");
//    	js.executeScript("document.getElementById('anouncement_end_date').value='Aug 26 2020 - 05:30 PM'");
		
		Thread.sleep(4000);
		
		driver.switchTo().frame(pageObjects.Communication_Announcement.iframebody);
		pageObjects.Communication_Announcement.CourseBodyText.sendKeys(details);
		driver.switchTo().defaultContent();
		
	}

	@When("^click create button$")
	public void click_create_button() throws Throwable {
		pageObjects.Communication_Announcement.AnnouncementCreateBtn.click();
	}

	@Then("^New Announcement shoud be created$")
	public void new_Announcement_shoud_be_created() throws Throwable {
		
		String alertmsg = pageObjects.Communication_Announcement.Confirmationmsg.getText();
//		Assert.assertTrue(alertmsg.contains("The Announcement was created"));
		if (alertmsg.contains("The Announcement was created"))
		  System.out.println("The New Announcement is created for " + org);
		else 
			System.out.println("The New Announcement is NOT created ");
		Thread.sleep(5000);
		tearDown();		
	}

	

}
