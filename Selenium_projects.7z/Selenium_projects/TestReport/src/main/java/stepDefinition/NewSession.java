package stepDefinition;

import java.util.List;

import org.openqa.selenium.support.PageFactory;

import appUtils.BaseClass;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class NewSession extends BaseClass {
	
	String sname,stype,sdesc;
	
	@When("^user click the create link$")
	public void user_click_the_create_link() throws Throwable {
		PageFactory.initElements(driver, pageObjects.CourseSession.class);
		pageObjects.CourseSession.CreateCourselink.click();
	}

	@When("^user click the Course Session link and then click the Add Session button in newly created course$")
	public void user_click_the_Course_Session_link_and_then_click_the_Add_Session_button_in_newly_created_course() throws Throwable {
		
		PageFactory.initElements(driver, pageObjects.CourseSession.class);
		pageObjects.CourseSession.coursesessionslink.click();
		pageObjects.CourseSession.addsessionbtn.click();
		
		
	}

	@When("^user enters session name, session type and session description$")
	public void user_enters_session_name_session_type_and_session_description(DataTable sestbl) throws Throwable {
		
		List<List<String>> sessdata = sestbl.raw();
		sname = sessdata.get(1).get(0);
		stype = sessdata.get(1).get(1);
		sdesc = sessdata.get(1).get(2);
		
		pageObjects.CourseSession.sessionname.sendKeys(sname);
		pageObjects.CourseSession.sessiontype.sendKeys(stype);
		pageObjects.CourseSession.sessiondescription.sendKeys(sdesc);
		
	}

	@When("^click the create button for create session$")
	public void click_the_create_button_for_create_session() throws Throwable {
		pageObjects.CourseSession.createsessionbtn.click();
		

	}

	@Then("^Session Should be created successfully$")
	public void session_Should_be_created_successfully() throws Throwable {
		
		String alertmsg = pageObjects.CourseSession.Confirmationmsg.getText();
		Assert.assertTrue(alertmsg.contains("The session was created"));
		System.out.println("'" + sname + "' Session was created Successfully");

	}

}
