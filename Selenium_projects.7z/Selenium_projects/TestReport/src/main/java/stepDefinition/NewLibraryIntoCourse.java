package stepDefinition;

import java.util.List;

import org.openqa.selenium.support.PageFactory;

import appUtils.BaseClass;
import cucumber.api.DataTable;
import cucumber.api.java.en.When;

public class NewLibraryIntoCourse extends BaseClass {

	static String textcardtitle;
	static String textfilename;

	@When("^User click the Text content icon and navigate to library tab and enter Card Title and enter Text File Name in the search icon and select the file from the table$")
	public void user_click_the_Text_content_icon_and_navigate_to_library_tab_and_enter_Card_Title_and_enter_Text_File_Name_in_the_search_icon_and_select_the_file_from_the_table(DataTable txtlib) throws Throwable {

		List<List<String>> carddata = txtlib.raw();
		textcardtitle = carddata.get(1).get(0);
		textfilename = carddata.get(1).get(1);

		PageFactory.initElements(driver, pageObjects.CourseSession.class);
		wait(pageObjects.CourseSession.CourseTextlink);
		pageObjects.CourseSession.CourseTextlink.click();
		Thread.sleep(2000);
		pageObjects.CourseSession.Libraryspan.click();

		try {
			pageObjects.CourseSession.CourseTitlelink.clear();
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{			
			pageObjects.CourseSession.CourseTitlelink.clear();
		}

		try {

			wait(pageObjects.CourseSession.CourseTitlelink);
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{			
			wait(pageObjects.CourseSession.CourseTitlelink);
		}
		pageObjects.CourseSession.CourseTitlelink.sendKeys(textcardtitle);
		//		Thread.sleep(2000);
		wait(pageObjects.CourseSession.LibrarySearchIcon);
		pageObjects.CourseSession.LibrarySearchIcon.sendKeys(textfilename);
		wait(pageObjects.CourseSession.LibraryListItems);
		pageObjects.CourseSession.LibraryListItems.click();	
		Thread.sleep(2000);

	}

}
