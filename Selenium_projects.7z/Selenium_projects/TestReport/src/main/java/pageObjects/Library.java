package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Library {
	
	@FindBy(xpath = "//a[contains(text(),'Create')]")
	public static WebElement CreateCourselink;
	
	@FindBy(xpath = "//a[@data-target='#libraryitems']")
	public static WebElement LibrariesMainMenu;
	
	
	@FindBy(xpath = "//a[@id='createmenu_mylibrary']/p")
	public static WebElement MyLibrariesMenu;
	
	@FindBy(xpath = "//a[contains(text(),'Add New Resources')]")
	public static WebElement AddNewResourceBtn;
		
	@FindBy(id = "file-picker-btn")
	public static WebElement FileUploadBtn;
	
	@FindBy(id = "file-picker")
	public static WebElement libUploadlink;
	
	@FindBy(xpath = "//button[contains(text(),'Update')]")
	public static WebElement UploadLibraryBtn;
	
	@FindBy(xpath = "//*[@id='layoutSidenav_content']/main/div[1]")
	public static WebElement Confirmationmsg;
}
