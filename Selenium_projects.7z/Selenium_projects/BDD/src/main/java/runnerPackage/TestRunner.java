package runnerPackage;
import org.junit.runner.RunWith;
import org.testng.annotations.AfterSuite;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src/test/java/featureFile/",
		glue = "stepDefinition",
//	dryRun = true,
		monochrome = true,
		plugin = {"pretty","html:target/HTMLReport",
				"json:target/cucumber-reports/cucumber.json",
		        "junit:target/cucumber-reports/cucumber.xml"},
		

//      	"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
		tags = {"@login"}

		)

public class TestRunner extends AbstractTestNGCucumberTests{
	
	@AfterSuite
	public void generateReport() {
		appUtils.ReportingUtils.generateJVMReport();
	}

}
