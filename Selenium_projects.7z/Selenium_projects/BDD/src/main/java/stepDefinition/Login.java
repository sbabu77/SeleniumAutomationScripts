package stepDefinition;

import java.util.List;

import org.openqa.selenium.support.PageFactory;

import appUtils.BaseClass;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login extends BaseClass{
	
	String email,validationmsg;
	String user,usertxt;
	
	@When("^user click the forgot password link and enter below username in the email id field and click submit button$")
	public void user_click_the_forgot_password_link_and_enter_below_username_in_the_email_id_field_and_click_submit_button(DataTable logintable) throws Throwable {
	 
		List<List<String>> logindata = logintable.raw();
		email = logindata.get(1).get(0);

		PageFactory.initElements(driver, pageObjects.Login.class);
		
		pageObjects.Login.forgotpasswordlink.click();
		pageObjects.Login.forgotemail.sendKeys(email);
		pageObjects.Login.forgotpwdsubmitbtn.click();
	}
	
	@When("^user enters invalid credential of \"([^\"]*)\" and \"([^\"]*)\" and then click the submit button$")
	public void user_enters_invalid_credential_of_and_and_then_click_the_submit_button(String uName, String pwd) throws Throwable {
		PageFactory.initElements(driver, pageObjects.Login.class);
		pageObjects.Login.loginusername.sendKeys(uName);
		pageObjects.Login.loginpwd.sendKeys(pwd);
		pageObjects.Login.loginsubmitbtn.click();
		validationmsg = pageObjects.Login.validationmessage.getText();
		
		if (validationmsg.contains("Invalid credentials"))
		{System.out.println("Please check credential...credentials are wrong...");}
	}

	
	@Then("^user should not able to login into application and print validation message$")
	public void user_should_not_able_to_login_into_application_and_print_validation_message() throws Throwable {
		
		PageFactory.initElements(driver, pageObjects.Login.class);
		validationmsg = pageObjects.Login.validationmessage.getText();
		System.out.println(validationmsg);
		
	 	}

	
	@Then("^password reset link sent to your email message should display and user click return to login button and navigate to home page$")
	public void password_reset_link_sent_to_your_email_message_should_display_and_user_click_return_to_login_button_and_navigate_to_home_page() throws Throwable {
	
		PageFactory.initElements(driver, pageObjects.Login.class);
		validationmsg = pageObjects.Login.validationmessage.getText();
		if (validationmsg.contains("Password reset link has been sent to your email")) 
		{System.out.println("Password reset link has been sent to your email. Please check and reset your password");}
		
		pageObjects.Login.returntologinlink.click();
		
	}
	
	@Then("^logout and close the browser$")
	public void logout_and_close_the_browser() throws Throwable {
	  
		logout();
		tearDown();
		
	}
	
	@Then("^close the browser$")
	public void close_the_browser() throws Throwable {
		tearDown();
	}
	

	
	@Then("^user should able to login into home page of curator application and username user display in the homepage$")
	public void user_should_able_to_login_into_home_page_of_curator_application_and_username_user_display_in_the_homepage(DataTable arg1) throws Throwable {
		
		List<List<String>> usrdata = arg1.raw();
		user = usrdata.get(1).get(0);
		
		PageFactory.initElements(driver, pageObjects.Login.class);
		usertxt = pageObjects.Login.username.getText();
//		System.out.println("user login name : " +usertxt);
		
		if (usertxt.contains(user))
			System.out.println("logged into as a "+usertxt+ " user" );
		else
			System.out.println(user + " is not logged in");
	
	}

}


