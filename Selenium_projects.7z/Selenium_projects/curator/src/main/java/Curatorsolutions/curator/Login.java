package Curatorsolutions.curator;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Login {

	public static void main(String[] args) {
		
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Visio\\Automation\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://elearis-test.shyftcloud.com/login");
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	String uName = "University of Madras Test";
	driver.findElement(By.id("username")).sendKeys("test@curatorsolutions.com");
	driver.findElement(By.id("password")).sendKeys("Test$Pwd123");
	driver.findElement(By.id("_submit")).click();

	// Organization
	driver.findElement(By.xpath("//a[@data-target='#organizationitems']")).click();
	driver.findElement(By.xpath("//p[contains(text(),'Organizations')]")).click();  
	
	driver.findElement(By.xpath("//a[contains(text(),'New Institution')]")).click();
	
	driver.findElement(By.id("university_name")).sendKeys(uName);
	WebElement orgtype = driver.findElement(By.id("university_organizationType"));
	orgtype.click();
	
	Select orgselect = new Select(orgtype);
	orgselect.selectByVisibleText("Higher Education");
	
	driver.findElement(By.id("university_url")).sendKeys("https://www.unomtest.ac.in/");
	driver.findElement(By.id("university_acronym")).sendKeys("UOM");
	WebElement langselect = driver.findElement(By.id("university_defContentLang"));
	langselect.click();
	
	Select langcontselect = new Select(langselect);
	langcontselect.selectByVisibleText("English");
	
	driver.findElement(By.id("btnUniversitySubmit")).click();
	
	String alertmsg = driver.findElement(By.xpath("//*[@id='layoutSidenav_content']/main/div[1]")).getText();
	if (alertmsg.contains("The university was created"))
		System.out.println("The University " + uName+" is created successfully");
	


	}

}
